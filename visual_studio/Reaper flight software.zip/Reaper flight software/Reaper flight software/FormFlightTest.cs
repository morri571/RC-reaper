﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;

namespace Reaper_flight_software
{
    public partial class FormFlightTest : System.Windows.Forms.Form
    {
        private string[] portNames;
        private bool configured = false; //is the port configured with properties?
        private bool throttleOnOff = false; //is the throttle on or off?
        private bool readyToSend = true; //is the arduino ready to receive data from the app?
        private SerialPort arduinoPort = new SerialPort();

        private string throttleBuffer = null;
        const string DELIMITER = "_";
        

        public FormFlightTest()
        {
            InitializeComponent();
        }

        #region events

        private void Form_Load(object sender, EventArgs e)
        {
            portNames = SerialPort.GetPortNames(); //probably going to be changed
            foreach (string port in portNames)
            {
                comboBoxPortNames.Items.Add(port);
            }

            comboBoxBaudRate.SelectedIndex = 0;
            comboBoxPortNames.SelectedIndex = 0;
            comboBoxParityBits.SelectedIndex = 0;
            comboBoxDataBits.SelectedIndex = 3;
            comboBoxStopBits.SelectedIndex = 1;
        }

        private void buttonConfigure_Click(object sender, EventArgs e)
        {
            try
            {
                arduinoPort.PortName = comboBoxPortNames.Text;
                arduinoPort.BaudRate = Int32.Parse(comboBoxBaudRate.Text);
                arduinoPort.Parity = (Parity)comboBoxParityBits.SelectedIndex;
                arduinoPort.DataBits = Int32.Parse(comboBoxDataBits.Text);
                arduinoPort.StopBits = (StopBits)comboBoxStopBits.SelectedIndex;

                arduinoPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);

                arduinoPort.Open();

                configured = true;
            }

            catch 
            {
                MessageBox.Show("Configuration Invalid or Port Not Open");

                configured = false;
            }
        }

        private void throttleTrackBar_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(throttleOnOff == true)
            {
                if (e.KeyChar == 'w' && throttleTrackBar.Value < throttleTrackBar.Maximum)
                {
                    throttleTrackBar.Value += 1;
                }
                else if (e.KeyChar == 's' && throttleTrackBar.Value > throttleTrackBar.Minimum)
                {
                    throttleTrackBar.Value -= 1;
                }
            }
        }

        private void throttleTrackBar_ValueChanged(object sender, EventArgs e)
        {
            throttleBuffer = "-1" + DELIMITER
            + throttleTrackBar.Value.ToString() + DELIMITER
            + "256" + "\n";

            if (configured == true && readyToSend == true)
            {
                readyToSend = false;
                write(throttleBuffer);
            }
        }

        private void checkBoxPower_CheckedChanged(object sender, EventArgs e)
        {
            //CheckBox cb = (CheckBox)sender;
            checkBoxPower.BackColor = checkBoxPower.Checked ? Color.Lime : Color.Red;
            throttleOnOff = checkBoxPower.Checked ? true : false;

            throttleControl(throttleOnOff);
        }

        #endregion events

        private void write(string data)
        {
            if(configured == true)
            {
                arduinoPort.Write(data);
            }
        }

        private void read(string data)
        {

        }

        private void throttleControl(bool throttleOnOff)
        {
            if (throttleOnOff == false)
            {
                throttleTrackBar.Value = 0;
                throttleTrackBar.Enabled = false;
            }
            else
            {
                throttleTrackBar.Enabled = true;
            }
        }

        private void buttonClosePort_Click(object sender, EventArgs e)
        {
            if(arduinoPort.IsOpen == true)
            {
                configured = false;
                throttleTrackBar.Value = 0;
                throttleTrackBar.Enabled = false;
                checkBoxPower.Checked = false;
                arduinoPort.Close();
            }
        }

        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            Int32 temp = Int32.Parse(arduinoPort.ReadExisting()); //used to make sure the arduino code has executed and is ready for new data
            readyToSend = true;
        }

    }
}
