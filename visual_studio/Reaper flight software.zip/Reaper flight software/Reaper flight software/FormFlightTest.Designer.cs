﻿using System.Windows.Forms;

namespace Reaper_flight_software
{
    partial class FormFlightTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        /// 

        private TrackBar throttleTrackBar;
        private Label throttleLabel;
        private NumericUpDown pitchNumericUpDown;
        private Label pitchLabel;
        private NumericUpDown yawNumericUpDown;
        private Label yawLabel;
        private NumericUpDown rollNumericUpDown;
        private Label rollLabel;

        private void InitializeComponent()
        {
            this.throttleTrackBar = new System.Windows.Forms.TrackBar();
            this.throttleLabel = new System.Windows.Forms.Label();
            this.pitchNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.pitchLabel = new System.Windows.Forms.Label();
            this.yawNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.yawLabel = new System.Windows.Forms.Label();
            this.rollNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.rollLabel = new System.Windows.Forms.Label();
            this.buttonConfigure = new System.Windows.Forms.Button();
            this.comboBoxBaudRate = new System.Windows.Forms.ComboBox();
            this.buttonClosePort = new System.Windows.Forms.Button();
            this.labelBaudRate = new System.Windows.Forms.Label();
            this.labelPortNames = new System.Windows.Forms.Label();
            this.comboBoxPortNames = new System.Windows.Forms.ComboBox();
            this.labelParityBits = new System.Windows.Forms.Label();
            this.comboBoxParityBits = new System.Windows.Forms.ComboBox();
            this.labelDataBits = new System.Windows.Forms.Label();
            this.comboBoxDataBits = new System.Windows.Forms.ComboBox();
            this.labelStopBits = new System.Windows.Forms.Label();
            this.comboBoxStopBits = new System.Windows.Forms.ComboBox();
            this.checkBoxPower = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.throttleTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pitchNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yawNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rollNumericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // throttleTrackBar
            // 
            this.throttleTrackBar.BackColor = System.Drawing.Color.Indigo;
            this.throttleTrackBar.Enabled = false;
            this.throttleTrackBar.Location = new System.Drawing.Point(480, 57);
            this.throttleTrackBar.Maximum = 51;
            this.throttleTrackBar.Name = "throttleTrackBar";
            this.throttleTrackBar.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.throttleTrackBar.Size = new System.Drawing.Size(45, 355);
            this.throttleTrackBar.TabIndex = 0;
            this.throttleTrackBar.ValueChanged += new System.EventHandler(this.throttleTrackBar_ValueChanged);
            this.throttleTrackBar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.throttleTrackBar_KeyPress);
            // 
            // throttleLabel
            // 
            this.throttleLabel.AutoSize = true;
            this.throttleLabel.Location = new System.Drawing.Point(477, 41);
            this.throttleLabel.Name = "throttleLabel";
            this.throttleLabel.Size = new System.Drawing.Size(46, 13);
            this.throttleLabel.TabIndex = 1;
            this.throttleLabel.Text = "Throttle:";
            // 
            // pitchNumericUpDown
            // 
            this.pitchNumericUpDown.Location = new System.Drawing.Point(53, 392);
            this.pitchNumericUpDown.Name = "pitchNumericUpDown";
            this.pitchNumericUpDown.Size = new System.Drawing.Size(100, 20);
            this.pitchNumericUpDown.TabIndex = 1;
            // 
            // pitchLabel
            // 
            this.pitchLabel.AutoSize = true;
            this.pitchLabel.Location = new System.Drawing.Point(50, 350);
            this.pitchLabel.Name = "pitchLabel";
            this.pitchLabel.Size = new System.Drawing.Size(34, 13);
            this.pitchLabel.TabIndex = 2;
            this.pitchLabel.Text = "Pitch:";
            // 
            // yawNumericUpDown
            // 
            this.yawNumericUpDown.Location = new System.Drawing.Point(203, 392);
            this.yawNumericUpDown.Name = "yawNumericUpDown";
            this.yawNumericUpDown.Size = new System.Drawing.Size(100, 20);
            this.yawNumericUpDown.TabIndex = 2;
            // 
            // yawLabel
            // 
            this.yawLabel.AutoSize = true;
            this.yawLabel.Location = new System.Drawing.Point(200, 350);
            this.yawLabel.Name = "yawLabel";
            this.yawLabel.Size = new System.Drawing.Size(31, 13);
            this.yawLabel.TabIndex = 3;
            this.yawLabel.Text = "Yaw:";
            // 
            // rollNumericUpDown
            // 
            this.rollNumericUpDown.Location = new System.Drawing.Point(353, 392);
            this.rollNumericUpDown.Name = "rollNumericUpDown";
            this.rollNumericUpDown.Size = new System.Drawing.Size(100, 20);
            this.rollNumericUpDown.TabIndex = 3;
            // 
            // rollLabel
            // 
            this.rollLabel.AutoSize = true;
            this.rollLabel.Location = new System.Drawing.Point(350, 350);
            this.rollLabel.Name = "rollLabel";
            this.rollLabel.Size = new System.Drawing.Size(28, 13);
            this.rollLabel.TabIndex = 4;
            this.rollLabel.Text = "Roll:";
            // 
            // buttonConfigure
            // 
            this.buttonConfigure.BackColor = System.Drawing.Color.Lime;
            this.buttonConfigure.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonConfigure.Location = new System.Drawing.Point(22, 44);
            this.buttonConfigure.Name = "buttonConfigure";
            this.buttonConfigure.Size = new System.Drawing.Size(122, 36);
            this.buttonConfigure.TabIndex = 5;
            this.buttonConfigure.Text = "Configure";
            this.buttonConfigure.UseVisualStyleBackColor = false;
            this.buttonConfigure.Click += new System.EventHandler(this.buttonConfigure_Click);
            // 
            // comboBoxBaudRate
            // 
            this.comboBoxBaudRate.FormattingEnabled = true;
            this.comboBoxBaudRate.Items.AddRange(new object[] {
            "9600",
            "115200"});
            this.comboBoxBaudRate.Location = new System.Drawing.Point(163, 69);
            this.comboBoxBaudRate.Name = "comboBoxBaudRate";
            this.comboBoxBaudRate.Size = new System.Drawing.Size(121, 21);
            this.comboBoxBaudRate.TabIndex = 6;
            // 
            // buttonClosePort
            // 
            this.buttonClosePort.BackColor = System.Drawing.Color.Red;
            this.buttonClosePort.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonClosePort.Location = new System.Drawing.Point(22, 87);
            this.buttonClosePort.Name = "buttonClosePort";
            this.buttonClosePort.Size = new System.Drawing.Size(122, 36);
            this.buttonClosePort.TabIndex = 7;
            this.buttonClosePort.Text = "Close Port";
            this.buttonClosePort.UseVisualStyleBackColor = false;
            this.buttonClosePort.Click += new System.EventHandler(this.buttonClosePort_Click);
            // 
            // labelBaudRate
            // 
            this.labelBaudRate.Location = new System.Drawing.Point(299, 72);
            this.labelBaudRate.Name = "labelBaudRate";
            this.labelBaudRate.Size = new System.Drawing.Size(58, 18);
            this.labelBaudRate.TabIndex = 8;
            this.labelBaudRate.Text = "Baud Rate";
            // 
            // labelPortNames
            // 
            this.labelPortNames.Location = new System.Drawing.Point(299, 46);
            this.labelPortNames.Name = "labelPortNames";
            this.labelPortNames.Size = new System.Drawing.Size(58, 18);
            this.labelPortNames.TabIndex = 10;
            this.labelPortNames.Text = "Ports";
            // 
            // comboBoxPortNames
            // 
            this.comboBoxPortNames.FormattingEnabled = true;
            this.comboBoxPortNames.Location = new System.Drawing.Point(163, 43);
            this.comboBoxPortNames.Name = "comboBoxPortNames";
            this.comboBoxPortNames.Size = new System.Drawing.Size(121, 21);
            this.comboBoxPortNames.TabIndex = 9;
            // 
            // labelParityBits
            // 
            this.labelParityBits.Location = new System.Drawing.Point(299, 99);
            this.labelParityBits.Name = "labelParityBits";
            this.labelParityBits.Size = new System.Drawing.Size(58, 18);
            this.labelParityBits.TabIndex = 14;
            this.labelParityBits.Text = "Parity Bits";
            // 
            // comboBoxParityBits
            // 
            this.comboBoxParityBits.FormattingEnabled = true;
            this.comboBoxParityBits.Items.AddRange(new object[] {
            "None",
            "Odd",
            "Even",
            "Mark",
            "Space"});
            this.comboBoxParityBits.Location = new System.Drawing.Point(163, 96);
            this.comboBoxParityBits.Name = "comboBoxParityBits";
            this.comboBoxParityBits.Size = new System.Drawing.Size(121, 21);
            this.comboBoxParityBits.TabIndex = 13;
            // 
            // labelDataBits
            // 
            this.labelDataBits.Location = new System.Drawing.Point(299, 125);
            this.labelDataBits.Name = "labelDataBits";
            this.labelDataBits.Size = new System.Drawing.Size(58, 18);
            this.labelDataBits.TabIndex = 12;
            this.labelDataBits.Text = "Data Bits";
            // 
            // comboBoxDataBits
            // 
            this.comboBoxDataBits.FormattingEnabled = true;
            this.comboBoxDataBits.Items.AddRange(new object[] {
            "5",
            "6",
            "7",
            "8"});
            this.comboBoxDataBits.Location = new System.Drawing.Point(163, 122);
            this.comboBoxDataBits.Name = "comboBoxDataBits";
            this.comboBoxDataBits.Size = new System.Drawing.Size(121, 21);
            this.comboBoxDataBits.TabIndex = 11;
            // 
            // labelStopBits
            // 
            this.labelStopBits.Location = new System.Drawing.Point(299, 152);
            this.labelStopBits.Name = "labelStopBits";
            this.labelStopBits.Size = new System.Drawing.Size(58, 18);
            this.labelStopBits.TabIndex = 18;
            this.labelStopBits.Text = "Stop Bits";
            // 
            // comboBoxStopBits
            // 
            this.comboBoxStopBits.FormattingEnabled = true;
            this.comboBoxStopBits.Items.AddRange(new object[] {
            "None",
            "One",
            "OnePointFive",
            "Two"});
            this.comboBoxStopBits.Location = new System.Drawing.Point(163, 149);
            this.comboBoxStopBits.Name = "comboBoxStopBits";
            this.comboBoxStopBits.Size = new System.Drawing.Size(121, 21);
            this.comboBoxStopBits.TabIndex = 17;
            // 
            // checkBoxPower
            // 
            this.checkBoxPower.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBoxPower.BackColor = System.Drawing.Color.Red;
            this.checkBoxPower.Location = new System.Drawing.Point(542, 57);
            this.checkBoxPower.Name = "checkBoxPower";
            this.checkBoxPower.Size = new System.Drawing.Size(48, 60);
            this.checkBoxPower.TabIndex = 19;
            this.checkBoxPower.Text = "On/Off";
            this.checkBoxPower.UseVisualStyleBackColor = false;
            this.checkBoxPower.CheckedChanged += new System.EventHandler(this.checkBoxPower_CheckedChanged);
            // 
            // FormFlightTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(809, 435);
            this.Controls.Add(this.checkBoxPower);
            this.Controls.Add(this.labelStopBits);
            this.Controls.Add(this.comboBoxStopBits);
            this.Controls.Add(this.labelParityBits);
            this.Controls.Add(this.comboBoxParityBits);
            this.Controls.Add(this.labelDataBits);
            this.Controls.Add(this.comboBoxDataBits);
            this.Controls.Add(this.labelPortNames);
            this.Controls.Add(this.comboBoxPortNames);
            this.Controls.Add(this.labelBaudRate);
            this.Controls.Add(this.buttonClosePort);
            this.Controls.Add(this.comboBoxBaudRate);
            this.Controls.Add(this.buttonConfigure);
            this.Controls.Add(this.throttleTrackBar);
            this.Controls.Add(this.throttleLabel);
            this.Controls.Add(this.pitchNumericUpDown);
            this.Controls.Add(this.pitchLabel);
            this.Controls.Add(this.yawNumericUpDown);
            this.Controls.Add(this.yawLabel);
            this.Controls.Add(this.rollNumericUpDown);
            this.Controls.Add(this.rollLabel);
            this.Name = "FormFlightTest";
            this.Text = "Flight Test Software";
            this.Load += new System.EventHandler(this.Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.throttleTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pitchNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yawNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rollNumericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private Button buttonConfigure;
        private ComboBox comboBoxBaudRate;
        private Button buttonClosePort;
        private Label labelBaudRate;
        private Label labelPortNames;
        private ComboBox comboBoxPortNames;
        private Label labelParityBits;
        private ComboBox comboBoxParityBits;
        private Label labelDataBits;
        private ComboBox comboBoxDataBits;
        private Label labelStopBits;
        private ComboBox comboBoxStopBits;
        private CheckBox checkBoxPower;
    }
}

#endregion Windows Form Designer generated code